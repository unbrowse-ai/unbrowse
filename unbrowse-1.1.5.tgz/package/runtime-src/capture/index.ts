import { BrowserManager } from "agent-browser/dist/browser.js";
import { executeCommand } from "agent-browser/dist/actions.js";
import { nanoid } from "nanoid";
import { existsSync } from "node:fs";
import { getRegistrableDomain } from "../domain.js";
import { getProfilePath } from "../auth/index.js";
import { log } from "../logger.js";
import { scanBundlesForGraphQLOps, type GraphQLOperationMap } from "../reverse-engineer/bundle-scanner.js";

// BUG-GC-012: Use a real Chrome UA — HeadlessChrome is actively blocked by Google and others.
const CHROME_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";

// Browser launch semaphore: max 3 concurrent browsers
const MAX_CONCURRENT_BROWSERS = 3;
let activeBrowsers = 0;
const waitQueue: Array<() => void> = [];

// Active browser registry — tracked for graceful shutdown
const activeBrowserRegistry = new Set<InstanceType<typeof BrowserManager>>();

// Hard timeout per capture: 90s prevents stuck browsers from holding slots forever
const CAPTURE_TIMEOUT_MS = 90_000;
const BROWSER_CLOSE_TIMEOUT_MS = 4_000;

async function closeBrowserSafely(browser: InstanceType<typeof BrowserManager>): Promise<void> {
  await Promise.race([
    browser.close().catch(() => {}),
    new Promise<void>((resolve) => setTimeout(resolve, BROWSER_CLOSE_TIMEOUT_MS)),
  ]);
}

async function acquireBrowserSlot(): Promise<void> {
  if (activeBrowsers < MAX_CONCURRENT_BROWSERS) {
    activeBrowsers++;
    return;
  }
  return new Promise<void>((resolve) => {
    waitQueue.push(() => { activeBrowsers++; resolve(); });
  });
}

function releaseBrowserSlot(browser?: InstanceType<typeof BrowserManager>): void {
  if (browser) activeBrowserRegistry.delete(browser);
  activeBrowsers--;
  const next = waitQueue.shift();
  if (next) next();
}

/** Close all active browser instances — called on server shutdown. */
export async function shutdownAllBrowsers(): Promise<void> {
  await Promise.allSettled([...activeBrowserRegistry].map((b) => closeBrowserSafely(b)));
  activeBrowserRegistry.clear();
}

export interface CapturedWsMessage {
  url: string;
  direction: "sent" | "received";
  data: string;
  timestamp: string;
}

export interface CaptureResult {
  requests: RawRequest[];
  har_lineage_id: string;
  domain: string;
  cookies?: Array<{ name: string; value: string; domain: string; path?: string; httpOnly?: boolean; secure?: boolean }>;
  final_url: string;
  ws_messages?: CapturedWsMessage[];
  html?: string;
  js_bundles?: Map<string, string>;
}

export interface RawRequest {
  url: string;
  method: string;
  request_headers: Record<string, string>;
  request_body?: string;
  response_status: number;
  response_headers: Record<string, string>;
  response_body?: string;
  timestamp: string;
}

export function isBlockedAppShell(html?: string): boolean {
  if (!html) return false;
  return (
    /JavaScript is not available\./i.test(html) ||
    /switch to a supported browser/i.test(html) ||
    /Something went wrong, but don.?t fret/i.test(html) ||
    /class=["']errorContainer["']/i.test(html) ||
    /#placeholder,\s*#react-root\s*\{\s*display:\s*none/i.test(html)
  );
}

function shouldRetryEphemeralProfileError(error: unknown): boolean {
  const message = error instanceof Error ? error.message : String(error ?? "");
  return /persistentcontext|target page, context or browser has been closed|browser has been closed|page has been closed/i.test(message);
}

/**
 * Extract a route hint keyword from a URL path for intent-aware API waiting.
 * e.g., "/i/bookmarks" → "bookmark", "/dashboard/analytics" → "analytic"
 * Returns null if the path is too generic (root, single char, common SPA prefixes).
 */
function extractRouteHint(url: string): string | null {
  try {
    const pathname = new URL(url).pathname;
    // Walk path segments from the end — the last meaningful segment is most specific
    const segments = pathname.split("/").filter(Boolean);
    // Skip generic SPA prefixes
    const GENERIC = /^(i|app|dashboard|page|view|en|es|fr|de|#|_|index|home|main|me|@me|users?|channels?|guilds?|servers?|messages?|threads?|conversations?)$/i;
    for (let i = segments.length - 1; i >= 0; i--) {
      const seg = segments[i];
      if (seg.length <= 2 || GENERIC.test(seg) || /^\d+$/.test(seg) || /^\{.+\}$/.test(seg) || /^[0-9a-f-]{8,}$/i.test(seg)) continue;
      // Return lowercased stem (strip trailing 's' for simple plural handling)
      return seg.toLowerCase().replace(/s$/, "");
    }
  } catch { /* bad URL */ }
  return null;
}

/**
 * Extract a search query from an intent string.
 * e.g., "search for mickey mouse" → "mickey mouse"
 *       "find restaurants in NYC" → "restaurants in NYC"
 *       "get feed posts" → null (not a search intent)
 */
function extractSearchQuery(intent: string): string | null {
  const match = intent.match(
    /\b(?:search|find|look\s*up|query|lookup)\s+(?:for\s+)?(.+)/i
  );
  if (!match) return null;
  const query = match[1].trim();
  // Reject if the "query" is just a generic resource name (e.g., "events", "posts")
  if (/^(events?|posts?|feed|timeline|notifications?|messages?|users?|profiles?)$/i.test(query)) return null;
  return query.length >= 2 ? query : null;
}

function deriveIntentHints(captureUrl?: string, intent?: string): string[] {
  const derivedHints = new Set<string>();
  if (captureUrl) {
    const routeHint = extractRouteHint(captureUrl);
    if (routeHint) derivedHints.add(routeHint);
  }
  const lowerIntent = intent?.toLowerCase() ?? "";
  if (/\b(person|people|profile|profiles|user|users|member|members)\b/.test(lowerIntent)) {
    derivedHints.add("profile");
    derivedHints.add("users");
    derivedHints.add("userby");
  }
  if (/\b(company|companies|organization|organisations|business)\b/.test(lowerIntent)) {
    derivedHints.add("company");
    derivedHints.add("organization");
    derivedHints.add("about");
  }
  if (/\b(post|posts|tweet|tweets|status|statuses)\b/.test(lowerIntent)) {
    derivedHints.add("tweet");
    derivedHints.add("timeline");
    derivedHints.add("status");
  }
  if (/\b(guild|guilds|server|servers)\b/.test(lowerIntent)) {
    derivedHints.add("guild");
    derivedHints.add("guilds");
  }
  if (/\b(channel|channels)\b/.test(lowerIntent)) {
    derivedHints.add("channel");
    derivedHints.add("channels");
  }
  if (/\b(message|messages|dm|dms|chat|thread|threads|conversation|conversations)\b/.test(lowerIntent)) {
    derivedHints.add("message");
    derivedHints.add("messages");
    derivedHints.add("thread");
    derivedHints.add("threads");
  }
  if (/\b(topic|topics|trend|trending|hashtag|hashtags)\b/.test(lowerIntent)) {
    derivedHints.add("trend");
    derivedHints.add("explore");
    derivedHints.add("topic");
  }
  return [...derivedHints];
}

function hasCapturedHint(responseUrls: Iterable<string>, hint: string): boolean {
  const lowerHint = hint.toLowerCase();
  for (const url of responseUrls) {
    if (url.toLowerCase().includes(lowerHint)) return true;
  }
  return false;
}

async function maybeProbeIntentApis(
  browser: InstanceType<typeof BrowserManager>,
  captureUrl: string | undefined,
  intent: string | undefined,
  responseBodies: Map<string, string> | undefined,
): Promise<void> {
  if (!captureUrl || !responseBodies) return;
  const lowerIntent = intent?.toLowerCase() ?? "";
  let hostname = "";
  try {
    hostname = new URL(captureUrl).hostname.toLowerCase();
  } catch {
    return;
  }

  if (/discord\.com$/.test(hostname) && /\b(guild|guilds|server|servers)\b/.test(lowerIntent)) {
    if (hasCapturedHint(responseBodies.keys(), "/guild")) return;
    const probes = [
      { label: "User affinities guilds", path: "/api/v9/users/@me/affinities/guilds" },
      { label: "User guilds", path: "/api/v9/users/@me/guilds?with_counts=true" },
    ];
    try {
      const page = browser.getPage();
      for (const probe of probes) {
        if (hasCapturedHint(responseBodies.keys(), "/guild")) break;
        log("spa", `probing ${probe.label}: GET https://discord.com${probe.path}`);
        await page.evaluate(async (path: string) => {
          try {
            const response = await fetch(path, { credentials: "include" });
            await response.text();
          } catch {
            // best-effort probe
          }
        }, probe.path);
        await new Promise((r) => setTimeout(r, 1200));
      }
    } catch {
      // non-fatal
    }
  }
}

const CAPTURE_RESPONSE_NOISE = /user_flow|datasavermode|ces\/p2|intercom|badge_count|settings\.json|paymentfailure|saved_searches|launcher_settings|conversations|\/ping\b|verifiedorg|xchatdmsettings|scheduledpromotions|storytopic|sidebaruserrecommendations|subscriptions|live_pipeline|fleetline|authorizetoken|logintwittertoken/i;

export function hasUsefulCapturedResponses(
  responseUrls: Iterable<string>,
  captureUrl?: string,
  intent?: string,
): boolean {
  const usefulUrls = [...responseUrls].filter((url) => !CAPTURE_RESPONSE_NOISE.test(url));
  if (usefulUrls.length === 0) return false;
  const hints = deriveIntentHints(captureUrl, intent);
  if (hints.length === 0) return usefulUrls.length > 0;
  return usefulUrls.some((url) => {
    const lower = url.toLowerCase();
    return hints.some((hint) => lower.includes(hint));
  });
}

/**
 * Adaptive content-ready wait. Replaces flat 5s timeout.
 * Phase 1: 2s initial settle
 * Phase 2: If Cloudflare challenge detected, poll up to 15s for clearance
 * Phase 3: Wait for network idle (SPA API calls to complete)
 * Phase 4: Intent-aware API wait — if a route hint exists, wait for a matching API response
 * Worst case: 2 + 15 + 8 + 5 = 30s, well within CAPTURE_TIMEOUT_MS (90s).
 */
async function waitForContentReady(
  browser: InstanceType<typeof BrowserManager>,
  captureUrl?: string,
  intent?: string,
  responseBodies?: Map<string, string>,
): Promise<void> {
  // Phase 1: Initial settle — let the page start rendering
  await new Promise((r) => setTimeout(r, 2000));

  // Phase 2: Cloudflare challenge detection and wait
  try {
    const page = browser.getPage();
    const hasCfChallenge = await page.evaluate(() => {
      const html = document.documentElement.innerHTML;
      return (
        html.includes("challenge-platform") ||
        html.includes("cf_chl_opt") ||
        document.title === "Just a moment..." ||
        !!document.querySelector("#challenge-running, #challenge-form, .cf-browser-verification")
      );
    });

    if (hasCfChallenge) {
      log("capture", "Cloudflare challenge detected, waiting for clearance...");
      const CF_POLL_INTERVAL = 1500;
      const CF_MAX_WAIT = 15000;
      const cfStart = Date.now();

      while (Date.now() - cfStart < CF_MAX_WAIT) {
        await new Promise((r) => setTimeout(r, CF_POLL_INTERVAL));
        const stillBlocked = await page.evaluate(() => {
          return (
            document.title === "Just a moment..." ||
            !!document.querySelector("#challenge-running, #challenge-form, .cf-browser-verification")
          );
        }).catch(() => false);

        if (!stillBlocked) {
          log("capture", `Cloudflare cleared after ${Date.now() - cfStart}ms`);
          break;
        }
      }
    }
  } catch {
    // Page not available — skip CF detection
  }

  // Phase 3: Wait for network idle (SPA API calls to settle)
  try {
    const page = browser.getPage();
    await page.waitForLoadState("networkidle", { timeout: 8000 });
  } catch {
    // networkidle timeout is non-fatal — some sites never fully idle
  }

  // Phase 4: Intent-aware API wait — catch SPA lazy-loaded route-specific APIs
  // SPAs like x.com fire route-specific GraphQL queries (e.g., Bookmarks) after
  // the initial homepage APIs. If we have a route hint, wait for a matching response.
  if (captureUrl && responseBodies) {
    const derivedHints = new Set(deriveIntentHints(captureUrl, intent));
    const wantedHints = [...derivedHints].filter((hint) =>
      ![...responseBodies.keys()].some((u) => u.toLowerCase().includes(hint))
    );
    if (wantedHints.length > 0) {
      log("capture", `intent-aware wait: looking for API matching one of [${wantedHints.join(", ")}] (from ${captureUrl})`);
      try {
        const page = browser.getPage();
        await new Promise<void>((resolve) => {
          const timeout = setTimeout(resolve, 15000);
          const handler = (response: { url(): string }) => {
            const responseUrl = response.url().toLowerCase();
            const matchedHint = wantedHints.find((hint) => responseUrl.includes(hint));
            if (matchedHint) {
              log("capture", `intent-aware wait: matched ${matchedHint} via ${response.url().substring(0, 120)}`);
              clearTimeout(timeout);
              page.off("response", handler);
              setTimeout(resolve, 500);
            }
          };
          page.on("response", handler);
        });
      } catch {
        // Non-fatal — proceed with what we have
      }
    } else if (derivedHints.size > 0) {
      log("capture", `intent-aware wait: already captured API matching one of [${[...derivedHints].join(", ")}], skipping`);
    }
  }

  // Phase 5: generic SPA stimulus. Some sites only fire route-specific APIs after
  // a short scroll/viewport change on search/explore/tab pages.
  const lowerIntent = intent?.toLowerCase() ?? "";
  if (
    captureUrl &&
    responseBodies &&
    (
      /search|explore|trending|tabs|discover/i.test(captureUrl) ||
      /\b(person|people|profile|profiles|user|users|member|members|company|companies|organization|organisations|business|post|posts|tweet|tweets|status|statuses)\b/.test(lowerIntent)
    )
  ) {
    try {
      const before = responseBodies.size;
      const page = browser.getPage();
      await page.evaluate(() => window.scrollTo(0, Math.max(window.innerHeight, Math.min(document.body.scrollHeight, window.innerHeight * 2))));
      await new Promise((r) => setTimeout(r, 1200));
      await page.evaluate(() => window.scrollTo(0, 0));
      if (responseBodies.size === before) {
        await new Promise((r) => setTimeout(r, 2000));
      }
    } catch {
      // non-fatal
    }
  }

  // Phase 6: Search interaction — if the intent is a search query but the URL
  // is a generic homepage (no ?q= param, no /search path), find a search input
  // on the page, type the query, submit, and capture the resulting API calls.
  if (intent && responseBodies && captureUrl) {
    const searchQuery = extractSearchQuery(intent);
    const urlHasSearch = /[?&](q|query|search|term)=/i.test(captureUrl) || /\/search\b/i.test(captureUrl);
    if (searchQuery && !urlHasSearch) {
      try {
        const page = browser.getPage();
        const beforeCount = responseBodies.size;

        // Find a search input using common selectors
        const searchSelector = await page.evaluate(() => {
          const candidates = [
            'input[type="search"]',
            'input[name="q"]',
            'input[name="query"]',
            'input[name="search"]',
            'input[aria-label*="search" i]',
            'input[placeholder*="search" i]',
            'input[role="searchbox"]',
            'input[role="combobox"]',
          ];
          for (const sel of candidates) {
            const el = document.querySelector(sel) as HTMLInputElement | null;
            if (el && el.offsetParent !== null) return sel; // visible
          }
          return null;
        });

        if (searchSelector) {
          log("capture", `search interaction: found input "${searchSelector}", typing "${searchQuery}"`);

          // Focus, clear, and fill the search input
          await page.click(searchSelector);
          await page.fill(searchSelector, searchQuery);
          await new Promise((r) => setTimeout(r, 300));

          // Submit by pressing Enter
          await page.keyboard.press("Enter");

          // Wait for new API calls triggered by the search
          await new Promise<void>((resolve) => {
            const timeout = setTimeout(resolve, 10000);
            let newResponses = 0;
            const handler = () => {
              newResponses++;
              // Wait for at least one new response, then settle
              if (newResponses >= 1) {
                clearTimeout(timeout);
                // Give a short window for additional responses
                setTimeout(resolve, 1500);
                page.off("response", handler);
              }
            };
            page.on("response", handler);
          });

          // Additional settle for SPA re-renders
          try {
            await page.waitForLoadState("networkidle", { timeout: 5000 });
          } catch { /* non-fatal */ }

          const newApis = responseBodies.size - beforeCount;
          log("capture", `search interaction: captured ${newApis} new API responses after search`);
        } else {
          log("capture", `search interaction: no search input found on page`);
        }
      } catch (err) {
        log("capture", `search interaction failed: ${err instanceof Error ? err.message : err}`);
      }
    }
  }

  await maybeProbeIntentApis(browser, captureUrl, intent, responseBodies);
}

export async function captureSession(
  url: string,
  authHeaders?: Record<string, string>,
  cookies?: Array<{ name: string; value: string; domain: string; path?: string; secure?: boolean; httpOnly?: boolean; sameSite?: string; expires?: number }>,
  intent?: string,
  options?: { forceEphemeral?: boolean },
): Promise<CaptureResult> {
  await acquireBrowserSlot();
  const browser = new BrowserManager();
  activeBrowserRegistry.add(browser);
  const domain = new URL(url).hostname;
  const profileDir = getProfilePath(domain);
  const hasPersistentProfile = !options?.forceEphemeral && existsSync(profileDir);
  let captureTimedOut = false;
  let retryEphemeral = false;
  let captureError: unknown;
  const timeoutHandle = setTimeout(async () => {
    captureTimedOut = true;
    await closeBrowserSafely(browser);
  }, CAPTURE_TIMEOUT_MS);
  try {
    // Use persistent profile if one exists (from prior interactiveLogin).
    // This preserves localStorage/sessionStorage auth that cookie injection can't cover.
    // Falls back to ephemeral headless with cookie injection (bird pattern).
    if (hasPersistentProfile) {
      log("capture", `using persistent profile for ${domain}: ${profileDir}`);
    }
    await browser.launch({
      action: "launch",
      id: nanoid(),
      headless: true,
      userAgent: CHROME_UA,
      ...(hasPersistentProfile ? { profile: profileDir } : {}),
    });

  // Override Chromium's auto-set Client Hints headers — without this, Chromium 145+
  // sends sec-ch-ua: "HeadlessChrome" even when user-agent is spoofed to Chrome 131,
  // which is how LinkedIn/Google/Cloudflare detect headless browsers.
  const CLIENT_HINT_HEADERS: Record<string, string> = {
    "sec-ch-ua": '"Not_A Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"macOS"',
  };
  await browser.setExtraHeaders({ ...CLIENT_HINT_HEADERS, ...(authHeaders ?? {}) });
  if (cookies && cookies.length > 0) {
    await injectCookies(browser, cookies);
  }

  await browser.startHarRecording();
  browser.startRequestTracking();

  // Hook page.on('response') BEFORE navigation to capture all response bodies
  // including XHR/fetch calls made during initial page load
  const responseBodies = new Map<string, string>();
  const MAX_BODY_SIZE = 512 * 1024; // 512KB

  // Collect same-domain JS bundles for API route scanning
  const jsBundleBodies = new Map<string, string>();
  const MAX_JS_BUNDLE_SIZE = 2 * 1024 * 1024; // 2MB per bundle
  const MAX_JS_BUNDLES = 20;
  const MAX_WS_FRAME_SIZE = 128 * 1024; // 128KB
  let pageDomain: string | undefined;
  try { pageDomain = getRegistrableDomain(new URL(url).hostname); } catch { /* bad url */ }

  const wsMessages: CapturedWsMessage[] = [];
  const wsUrlMap = new Map<string, string>(); // requestId -> url
  const wsSeen = new Set<string>();
  const recordWsMessage = (
    wsUrl: string,
    direction: "sent" | "received",
    raw: unknown,
    timestamp: string,
  ): void => {
    let data = "";
    if (typeof raw === "string") data = raw;
    else if (Buffer.isBuffer(raw)) data = raw.toString("utf8");
    else if (raw != null) data = String(raw);
    if (!data || data.length > MAX_WS_FRAME_SIZE) return;
    const key = `${wsUrl}|${direction}|${timestamp}|${data}`;
    if (wsSeen.has(key)) return;
    wsSeen.add(key);
    wsMessages.push({ url: wsUrl, direction, data, timestamp });
  };

  try {
    const page = browser.getPage();
    page.on("response", async (response) => {
      try {
        const ct = response.headers()["content-type"] ?? "";
        const respUrl = response.url();

        // Capture JS bundles for API route scanning + GraphQL hash extraction.
        // Accept same-domain bundles and known CDN bundles (e.g. abs.twimg.com for x.com).
        const isJs = ct.includes("javascript") || /\.js(\?|$)/.test(respUrl);
        if (isJs && jsBundleBodies.size < MAX_JS_BUNDLES && pageDomain) {
          try {
            const jsDomain = getRegistrableDomain(new URL(respUrl).hostname);
            const isSameDomain = jsDomain === pageDomain;
            // Also accept CDN bundles: twimg.com (X), licdn.com (LinkedIn), fbcdn.net (Meta), etc.
            const isCdnBundle = !isSameDomain && /\.(twimg|licdn|fbcdn|fbsbx|gstatic|cloudfront)\./.test(respUrl);
            if (isSameDomain || isCdnBundle) {
              const body = await response.body();
              if (body.length <= MAX_JS_BUNDLE_SIZE) {
                jsBundleBodies.set(respUrl, body.toString("utf8"));
              }
            }
          } catch { /* body unavailable */ }
          return;
        }

        // Capture JSON, protobuf, and batch RPC responses (Google batchexecute etc.)
        const isDataResponse =
          ct.includes("application/json") ||
          ct.includes("+json") ||
          ct.includes("application/x-protobuf") ||
          ct.includes("text/plain") ||
          respUrl.includes("batchexecute") ||
          respUrl.includes("/api/");
        if (!isDataResponse) return;
        // Skip static assets
        if (/\.(js|css|woff2?|png|jpg|svg|ico)(\?|$)/.test(respUrl)) return;
        const body = await response.body();
        if (body.length > MAX_BODY_SIZE) return;
        responseBodies.set(respUrl, body.toString("utf8"));
      } catch {
        // Response body may be unavailable for redirects/aborted
      }
    });

    page.on("websocket", (ws: {
      url(): string;
      on(event: "framereceived" | "framesent", listener: (frame: { payload?: unknown }) => void): void;
    }) => {
      const wsUrl = ws.url();
      ws.on("framereceived", (frame) => {
        recordWsMessage(wsUrl, "received", frame?.payload, new Date().toISOString());
      });
      ws.on("framesent", (frame) => {
        recordWsMessage(wsUrl, "sent", frame?.payload, new Date().toISOString());
      });
    });
  } catch {
    // page not available — skip body capture
  }

  // CDP-based WebSocket capture
  try {
    const page = browser.getPage();
    const cdp = await page.context().newCDPSession(page);
    await cdp.send("Network.enable");

    cdp.on("Network.webSocketCreated", (params: { requestId: string; url: string }) => {
      wsUrlMap.set(params.requestId, params.url);
    });

    cdp.on("Network.webSocketFrameReceived", (params: { requestId: string; timestamp: number; response: { payloadData: string } }) => {
      recordWsMessage(
        wsUrlMap.get(params.requestId) ?? params.requestId,
        "received",
        params.response.payloadData,
        new Date(params.timestamp * 1000).toISOString(),
      );
    });

    cdp.on("Network.webSocketFrameSent", (params: { requestId: string; timestamp: number; response: { payloadData: string } }) => {
      recordWsMessage(
        wsUrlMap.get(params.requestId) ?? params.requestId,
        "sent",
        params.response.payloadData,
        new Date(params.timestamp * 1000).toISOString(),
      );
    });
  } catch {
    // CDP session unavailable — skip WS capture
  }

  await executeCommand({ action: "navigate", id: nanoid(), url }, browser);

  // Adaptive wait: handle Cloudflare challenges + SPA content loading + intent-aware API wait
  await waitForContentReady(browser, url, intent, responseBodies);

  // BUG-008: Share Cloudflare clearance cookies across subdomains
  try {
    const context = browser.getContext();
    if (context) {
      const allCookies = await context.cookies();
      const cfCookies = allCookies.filter(
        (c) => c.name === "__cf_bm" || c.name === "cf_clearance" || c.name.startsWith("__cf")
      );
      if (cfCookies.length > 0) {
        const baseDomain = getRegistrableDomain(new URL(url).hostname);
        const subdomainCookies = cfCookies.map((c) => ({
          ...c,
          domain: `.${baseDomain}`,
        }));
        try {
          await context.addCookies(subdomainCookies);
        } catch { /* CF cookie sharing is best-effort */ }
      }
    }
  } catch { /* context unavailable */ }

  const trackedRequests = browser.getRequests();
  const har_lineage_id = nanoid();

  // Debug: log all captured request URLs and response body map keys
  log("capture", `tracked ${trackedRequests.length} requests, ${responseBodies.size} response bodies`);
  for (const [bodyUrl] of responseBodies) {
    log("capture", `response body captured: ${bodyUrl.substring(0, 150)}`);
  }

  let final_url = url;
  let html: string | undefined;
  try {
    const page = browser.getPage();
    final_url = page.url();
    html = await page.content();
  } catch {}

  const requests: RawRequest[] = trackedRequests.map((r) => ({
    url: r.url,
    method: r.method,
    request_headers: r.headers,
    response_status: 0,
    response_headers: {},
    response_body: responseBodies.get(r.url),
    timestamp: new Date(r.timestamp).toISOString(),
  }));

  // Synthesize RawRequests for response bodies captured by the response listener
  // but missed by request tracking (e.g., SPA API calls during intent-aware wait).
  const trackedUrls = new Set(trackedRequests.map((r) => r.url));
  for (const [bodyUrl, body] of responseBodies) {
    if (!trackedUrls.has(bodyUrl)) {
      requests.push({
        url: bodyUrl,
        method: "GET",
        request_headers: {},
        response_status: 200,
        response_headers: {},
        response_body: body,
        timestamp: new Date().toISOString(),
      });
    }
  }

  // Extract session cookies so callers can persist auth for future executions
  const ctx = browser.getContext();
  const rawCookies = ctx ? await ctx.cookies().catch(() => []) : [];
  const sessionCookies = rawCookies.map((c) => ({
    name: c.name,
    value: c.value,
    domain: c.domain,
    path: c.path,
    httpOnly: c.httpOnly,
    secure: c.secure,
  }));

  if (captureTimedOut) throw new Error(`captureSession timed out after ${CAPTURE_TIMEOUT_MS}ms for ${url}`);
  log("capture", `captured ${jsBundleBodies.size} JS bundles for route scanning`);
  const responseBodyCount = responseBodies.size;
    if (
      hasPersistentProfile &&
      isBlockedAppShell(html) &&
      responseBodyCount < 10 &&
      !hasUsefulCapturedResponses(responseBodies.keys(), url, intent)
    ) {
      retryEphemeral = true;
      log("capture", `persistent profile rendered blocked app shell for ${url}; retrying with fresh ephemeral browser`);
    } else {
      return { requests, har_lineage_id, domain, cookies: sessionCookies.length > 0 ? sessionCookies : undefined, final_url, ws_messages: wsMessages.length > 0 ? wsMessages : undefined, html, js_bundles: jsBundleBodies.size > 0 ? jsBundleBodies : undefined };
    }
  } catch (error) {
    captureError = error;
    if (hasPersistentProfile && shouldRetryEphemeralProfileError(error)) {
      retryEphemeral = true;
      log("capture", `persistent profile failed for ${url}; retrying with fresh ephemeral browser (${error instanceof Error ? error.message : String(error)})`);
    } else {
      throw error;
    }
  } finally {
    clearTimeout(timeoutHandle);
    await closeBrowserSafely(browser);
    releaseBrowserSlot(browser);
  }
  if (retryEphemeral) {
    return captureSession(url, authHeaders, cookies, intent, { forceEphemeral: true });
  }
  if (captureError) throw captureError;
  throw new Error(`captureSession failed without returning a result for ${url}`);
}

export async function executeInBrowser(
  url: string,
  method: string,
  requestHeaders: Record<string, string>,
  body?: unknown,
  authHeaders?: Record<string, string>,
  cookies?: Array<{ name: string; value: string; domain: string; path?: string; secure?: boolean; httpOnly?: boolean; sameSite?: string; expires?: number }>
): Promise<{ status: number; data: unknown; trace_id: string }> {
  await acquireBrowserSlot();
  const browser = new BrowserManager();
  activeBrowserRegistry.add(browser);
  try {
  await browser.launch({ action: "launch", id: nanoid(), headless: true, userAgent: CHROME_UA });

  const allHeaders = { ...authHeaders, ...requestHeaders };
  if (Object.keys(allHeaders).length > 0) {
    await browser.setExtraHeaders(allHeaders);
  }
  if (cookies && cookies.length > 0) {
    await injectCookies(browser, cookies);
  }

  // No auth: use in-page fetch (original path)
  browser.startRequestTracking();
  const origin = new URL(url).origin;
  await executeCommand({ action: "navigate", id: nanoid(), url: origin }, browser);

  const page = browser.getPage();
  const result = await page.evaluate(
    async ({ url, method, headers, body }: { url: string; method: string; headers: Record<string, string>; body: unknown }) => {
      const res = await fetch(url, {
        method,
        headers,
        ...(body ? { body: JSON.stringify(body) } : {}),
      });
      const text = await res.text();
      let data: unknown;
      try { data = JSON.parse(text); } catch { data = text; }
      return { status: res.status, data };
    },
    { url, method, headers: requestHeaders, body }
  );

  return { ...result, trace_id: nanoid() };
  } finally {
    releaseBrowserSlot(browser);
  }
}

/**
 * Trigger-and-intercept execution: navigate to the page that originally
 * triggered an API call, let the site's own JS make the request (passing
 * CSRF checks, TLS fingerprinting, etc.), and intercept the response.
 *
 * This is the generalized version of bird's approach:
 * - Bird works because Twitter doesn't do TLS fingerprinting
 * - Sites like LinkedIn do, so we let their JS make the call
 * - The site's own code handles CSRF tokens, session state, etc.
 */

/**
 * Build a URL matcher for trigger-and-intercept response matching.
 *
 * Handles three endpoint patterns:
 * 1. Path-based GraphQL (X.com): /graphql/{hash}/{OperationName} — match on
 *    operation name, ignore the persisted-query hash which rotates on deploys.
 * 2. QueryId-based GraphQL (LinkedIn): ?queryId=name.hash — match on the
 *    semantic name before the dot.
 * 3. Regular REST endpoints: match on the base URL path.
 */
const GRAPHQL_PATH_RE = /\/graphql\/[^/]+\/([^/?]+)/;

export function buildTriggerMatcher(targetUrlPattern: string): (respUrl: string) => boolean {
  const stripped = targetUrlPattern.replace(/\{[^}]+\}/g, "");
  const targetBase = stripped.split("?")[0];

  // Pattern 1: path-based GraphQL — /graphql/{hash}/{OperationName}
  const gqlPathMatch = GRAPHQL_PATH_RE.exec(targetBase);
  if (gqlPathMatch) {
    const operationName = gqlPathMatch[1];
    // Match: any /graphql/{anything}/{OperationName} on the same origin
    const origin = targetBase.split("/i/api/graphql")[0] || targetBase.split("/graphql")[0];
    return (respUrl: string) => {
      const m = GRAPHQL_PATH_RE.exec(respUrl);
      return !!m && m[1] === operationName && respUrl.startsWith(origin);
    };
  }

  // Pattern 2: queryId-based GraphQL — ?queryId=semanticName.hash
  let targetQueryId: string | null = null;
  try {
    const tu = new URL(stripped.replace(/\{[^}]+\}/g, "x") || targetUrlPattern.replace(/\{[^}]+\}/g, "x"));
    const rawQueryId = tu.searchParams.get("queryId");
    targetQueryId = rawQueryId ? rawQueryId.split(".")[0] : null;
  } catch { /* skip */ }

  // Pattern 3: standard base-path matching
  return (respUrl: string) => {
    const baseMatch = respUrl.includes(targetBase);
    const queryIdMatch = !targetQueryId || respUrl.includes(targetQueryId);
    return baseMatch && queryIdMatch;
  };
}

export async function triggerAndIntercept(
  triggerUrl: string,
  targetUrlPattern: string,
  cookies: Array<{ name: string; value: string; domain: string; path?: string; secure?: boolean; httpOnly?: boolean; sameSite?: string; expires?: number }>,
  authHeaders?: Record<string, string>,
): Promise<{ status: number; data: unknown; trace_id: string; gql_ops?: GraphQLOperationMap }> {
  await acquireBrowserSlot();
  const browser = new BrowserManager();
  activeBrowserRegistry.add(browser);
  try {
    await browser.launch({ action: "launch", id: nanoid(), headless: true, userAgent: CHROME_UA });

    // Set extra headers (client hints to avoid headless detection)
    const headers: Record<string, string> = {
      "sec-ch-ua": '"Not_A Brand";v="8", "Chromium";v="131", "Google Chrome";v="131"',
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": '"macOS"',
      ...authHeaders,
    };
    await browser.setExtraHeaders(headers);
    await injectCookies(browser, cookies);

    const page = browser.getPage();

    const matchUrl = buildTriggerMatcher(targetUrlPattern);

    // Collect JS bundles during navigation for GraphQL hash refresh
    const jsBundles = new Map<string, string>();
    const MAX_TI_BUNDLES = 10;
    const MAX_TI_BUNDLE_SIZE = 2 * 1024 * 1024;
    let triggerDomain: string | undefined;
    try { triggerDomain = getRegistrableDomain(new URL(triggerUrl).hostname); } catch { /* skip */ }

    // Set up response interception BEFORE navigation
    let captured: { status: number; data: unknown } | null = null;
    const interceptPromise = new Promise<{ status: number; data: unknown }>((resolve) => {
      const timeout = setTimeout(() => {
        resolve({ status: 0, data: { error: "trigger_timeout", message: "Target API call not intercepted within 15s" } });
      }, 15000);

      page.on("response", async (response) => {
        const respUrl = response.url();

        // Collect same-domain JS bundles for GraphQL hash extraction
        if (triggerDomain && jsBundles.size < MAX_TI_BUNDLES) {
          const ct = response.headers()["content-type"] ?? "";
          const isJs = ct.includes("javascript") || /\.js(\?|$)/.test(respUrl);
          if (isJs) {
            try {
              const jsDomain = getRegistrableDomain(new URL(respUrl).hostname);
              const isSame = jsDomain === triggerDomain;
              const isCdn = !isSame && /\.(twimg|licdn|fbcdn|fbsbx|gstatic|cloudfront)\./.test(respUrl);
              if (isSame || isCdn) {
                const body = await response.body();
                if (body.length <= MAX_TI_BUNDLE_SIZE) {
                  jsBundles.set(respUrl, body.toString("utf8"));
                }
              }
            } catch { /* body unavailable */ }
          }
        }

        if (matchUrl(respUrl) && !captured) {
          captured = { status: response.status(), data: null };
          try {
            const body = await response.text();
            try { captured.data = JSON.parse(body); } catch { captured.data = body; }
          } catch {
            captured.data = null;
          }
          clearTimeout(timeout);
          resolve(captured);
        }
      });
    });

    // Navigate to the trigger page — the site's JS will make the API call.
    // Use domcontentloaded (not networkidle) — we only need the specific API call to fire,
    // not all network activity to settle. The interceptPromise resolves as soon as it's captured.
    const targetLabel = targetUrlPattern.replace(/\{[^}]+\}/g, "").split("?")[0].slice(-80);
    log("capture", `trigger-and-intercept: navigating to ${triggerUrl}, waiting for ${targetLabel}`);
    page.goto(triggerUrl, { waitUntil: "domcontentloaded", timeout: 20000 }).catch(() => null);

    const result = await interceptPromise;
    log("capture", `trigger-and-intercept: got status ${result.status} for ${targetLabel}`);

    // Extract fresh GraphQL operation hashes from collected bundles
    let gqlOps: GraphQLOperationMap | undefined;
    if (jsBundles.size > 0) {
      const ops = scanBundlesForGraphQLOps(jsBundles);
      if (Object.keys(ops).length > 0) {
        gqlOps = ops;
        log("capture", `trigger-and-intercept: extracted ${Object.keys(ops).length} fresh GraphQL hashes`);
      }
    }

    return { ...result, trace_id: nanoid(), gql_ops: gqlOps };
  } finally {
    releaseBrowserSlot(browser);
  }
}

/**
 * Sanitize and inject cookies into browser context.
 * Strips all fields except { name, value, domain, path } to avoid
 * Playwright CDP protocol errors from unexpected cookie properties.
 * Falls back to per-cookie injection if batch fails.
 */
async function injectCookies(
  browser: InstanceType<typeof BrowserManager>,
  cookies: Array<{
    name: string;
    value: string;
    domain: string;
    path?: string;
    secure?: boolean;
    httpOnly?: boolean;
    sameSite?: string;
    expires?: number;
  }>
): Promise<void> {
  const context = browser.getContext();
  if (!context) return;

  const sanitized = cookies.map((c) => ({
    name: c.name,
    value: c.value,
    domain: c.domain.startsWith(".") ? c.domain : `.${c.domain}`,
    path: c.path ?? "/",
    ...(c.secure != null ? { secure: c.secure } : {}),
    ...(c.httpOnly != null ? { httpOnly: c.httpOnly } : {}),
    ...(c.sameSite != null ? { sameSite: c.sameSite as "Strict" | "Lax" | "None" } : {}),
    ...(c.expires != null && c.expires > 0 ? { expires: c.expires } : {}),
  }));

  log("capture", `injecting ${sanitized.length} cookies for domains: ${[...new Set(sanitized.map((c) => c.domain))].join(", ")}`);
  try {
    await context.addCookies(sanitized);
  } catch (batchErr) {
    log("capture", `batch cookie injection failed: ${batchErr instanceof Error ? batchErr.message : batchErr} — falling back to per-cookie`);
    let injected = 0;
    for (const cookie of sanitized) {
      try {
        await context.addCookies([cookie]);
        injected++;
      } catch (err) {
        log("capture", `failed to inject cookie "${cookie.name}" for ${cookie.domain}: ${err instanceof Error ? err.message : err}`);
      }
    }
    log("capture", `per-cookie fallback: ${injected}/${sanitized.length} injected`);
  }
}
