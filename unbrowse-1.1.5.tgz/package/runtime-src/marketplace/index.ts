import { nanoid } from "nanoid";
import * as client from "../client/index.js";
import type { EndpointDescriptor, SkillManifest, VerificationStatus } from "../types/index.js";

type MergeEndpointsOptions = {
  agentId?: string;
  mergedAt?: string;
  skillVersion?: string;
};

const CONTRIBUTION_WEIGHTS = {
  new_endpoint: 1,
  better_schema: 0.35,
  better_params: 0.25,
  better_exec_strategy: 0.25,
  recovery_after_drift: 0.2,
  better_description: 0.1,
} as const;

export async function listSkills(): Promise<SkillManifest[]> {
  return client.listSkills();
}

export async function getSkill(skillId: string, scopeId?: string): Promise<SkillManifest | null> {
  return client.getSkill(skillId, scopeId);
}

export async function publishSkill(
  draft: Omit<SkillManifest, "skill_id" | "created_at" | "updated_at" | "version"> & {
    skill_id?: string;
    version?: string;
  }
): Promise<SkillManifest> {
  // Pre-cache locally so the skill is immediately available even if the remote publish
  // fails or EmergentDB hasn't indexed it yet (eventual consistency).
  const now = new Date().toISOString();
  const preCache = {
    ...draft,
    skill_id: draft.skill_id ?? nanoid(),
    created_at: now,
    updated_at: now,
    version: draft.version ?? "1.0.0",
  } as SkillManifest;
  client.cachePublishedSkill(preCache);

  if (client.isLocalOnlyMode()) {
    return preCache;
  }

  try {
    // Strip bulky fields from publish payload to reduce size (2MB → ~50KB).
    // response_schema: stored separately via updateEndpointSchema
    // semantic: local analysis artifact, not needed for marketplace
    // operation_graph: rebuilt from endpoints on the backend
    const { operation_graph: _og, ...draftNoGraph } = draft as Record<string, unknown>;
    const slimDraft = {
      ...draftNoGraph,
      endpoints: draft.endpoints?.map(({ response_schema: _rs, semantic: _sem, ...ep }) => ep),
    };
    const { warnings: _w, ...backendFields } = await client.publishSkill(slimDraft);
    // Merge draft with backend response — avoids read-after-write race
    const skill = { ...draft, ...backendFields } as SkillManifest;
    client.cachePublishedSkill(skill);
    return skill;
  } catch (err) {
    console.error("[publish] remote publish failed, using local cache:", (err as Error).message);
    return preCache;
  }
}

export async function updateEndpointScore(
  skillId: string,
  endpointId: string,
  score: number,
  status?: VerificationStatus
): Promise<void> {
  await client.updateEndpointScore(skillId, endpointId, score, status);
}

// --- Pure local helpers (no backend call) ---

export function mergeEndpoints(
  existing: EndpointDescriptor[],
  incoming: EndpointDescriptor[],
  opts?: MergeEndpointsOptions
): EndpointDescriptor[] {
  const merged = [...existing];
  const mergedAt = opts?.mergedAt ?? new Date().toISOString();
  for (const ep of incoming) {
    const dupeIndex = merged.findIndex(
      (e) =>
        e.method === ep.method &&
        normalizeTemplate(e.url_template) === normalizeTemplate(ep.url_template)
    );
    if (dupeIndex === -1) {
      merged.push(prepareIncomingEndpoint(ep, opts, mergedAt));
      continue;
    }

    const dupe = merged[dupeIndex]!;
    const mergedEndpoint: EndpointDescriptor = {
      ...dupe,
      ...ep,
      endpoint_id: dupe.endpoint_id,
      reliability_score: Math.max(dupe.reliability_score ?? 0, ep.reliability_score ?? 0),
      verification_status: dupe.verification_status === "verified" ? dupe.verification_status : ep.verification_status,
      exec_strategy: ep.exec_strategy ?? dupe.exec_strategy,
      dom_extraction: ep.dom_extraction ?? dupe.dom_extraction,
      semantic: ep.semantic ?? dupe.semantic,
      response_schema: ep.response_schema ?? dupe.response_schema,
      headers_template: ep.headers_template ?? dupe.headers_template,
      query: ep.query ?? dupe.query,
      path_params: ep.path_params ?? dupe.path_params,
      body: ep.body ?? dupe.body,
      trigger_url: ep.trigger_url ?? dupe.trigger_url,
    };
    const canonicalFingerprint = dupe.canonical_fingerprint ?? ep.canonical_fingerprint ?? computeCanonicalFingerprint(mergedEndpoint);
    mergedEndpoint.canonical_fingerprint = canonicalFingerprint;
    mergedEndpoint.lineage = mergeLineage(dupe, ep, mergedEndpoint, canonicalFingerprint, opts, mergedAt);
    merged[dupeIndex] = mergedEndpoint;
  }
  return merged;
}

export function normalizeTemplate(t: string): string {
  return t
    .replace(/\{[^}]+\}/g, "{}")
    .replace(/([?&]queryid=)([^?&]+)/gi, (_match, prefix: string, value: string) => {
      if (value === "{}") return `${prefix}${value}`;
      return `${prefix}${value.replace(/\.[a-f0-9]{8,}$/i, "")}`;
    })
    .toLowerCase();
}

function prepareIncomingEndpoint(
  endpoint: EndpointDescriptor,
  opts: MergeEndpointsOptions | undefined,
  mergedAt: string
): EndpointDescriptor {
  const canonicalFingerprint = endpoint.canonical_fingerprint ?? computeCanonicalFingerprint(endpoint);
  return {
    ...endpoint,
    canonical_fingerprint: canonicalFingerprint,
    lineage: createOrUpdateLineage(endpoint, canonicalFingerprint, opts, mergedAt),
  };
}

function mergeLineage(
  existing: EndpointDescriptor,
  incoming: EndpointDescriptor,
  merged: EndpointDescriptor,
  canonicalFingerprint: string,
  opts: MergeEndpointsOptions | undefined,
  mergedAt: string
): NonNullable<EndpointDescriptor["lineage"]> {
  const base = createOrUpdateLineage(existing, canonicalFingerprint, opts, mergedAt, false);
  const incomingLineage = createOrUpdateLineage(incoming, canonicalFingerprint, opts, mergedAt, false);
  const contribution = deriveContribution(existing, incoming, merged, mergedAt, opts?.agentId);

  return {
    lineage_id: base.lineage_id,
    canonical_fingerprint: canonicalFingerprint,
    created_at: base.created_at,
    created_by_agent_id: base.created_by_agent_id ?? incomingLineage.created_by_agent_id,
    first_skill_version: base.first_skill_version ?? incomingLineage.first_skill_version ?? opts?.skillVersion,
    last_merged_at: mergedAt,
    contributors: dedupeContributors([
      ...base.contributors,
      ...incomingLineage.contributors,
      ...(contribution ? [contribution] : []),
    ]),
  };
}

function createOrUpdateLineage(
  endpoint: EndpointDescriptor,
  canonicalFingerprint: string,
  opts: MergeEndpointsOptions | undefined,
  mergedAt: string,
  addDiscoverer = true
): NonNullable<EndpointDescriptor["lineage"]> {
  const base = endpoint.lineage;
  const contributors = dedupeContributors(base?.contributors ?? []);
  if (addDiscoverer && opts?.agentId) {
    contributors.push({
      agent_id: opts.agentId,
      role: "discoverer",
      contribution_kind: "new_endpoint",
      weight: CONTRIBUTION_WEIGHTS.new_endpoint,
      contributed_at: mergedAt,
    });
  }

  return {
    lineage_id: base?.lineage_id ?? `lineage-${endpoint.endpoint_id}`,
    canonical_fingerprint: canonicalFingerprint,
    created_at: base?.created_at ?? mergedAt,
    created_by_agent_id: base?.created_by_agent_id ?? opts?.agentId,
    first_skill_version: base?.first_skill_version ?? opts?.skillVersion,
    last_merged_at: mergedAt,
    contributors: dedupeContributors(contributors),
  };
}

function deriveContribution(
  existing: EndpointDescriptor,
  incoming: EndpointDescriptor,
  merged: EndpointDescriptor,
  mergedAt: string,
  agentId?: string
): NonNullable<EndpointDescriptor["lineage"]>["contributors"][number] | null {
  if (!agentId) return null;

  if (incoming.response_schema && !sameValue(existing.response_schema, merged.response_schema)) {
    return {
      agent_id: agentId,
      role: "improver",
      contribution_kind: "better_schema",
      weight: CONTRIBUTION_WEIGHTS.better_schema,
      contributed_at: mergedAt,
    };
  }

  if (
    incoming.exec_strategy &&
    incoming.exec_strategy !== existing.exec_strategy &&
    merged.exec_strategy === incoming.exec_strategy
  ) {
    return {
      agent_id: agentId,
      role: "improver",
      contribution_kind: "better_exec_strategy",
      weight: CONTRIBUTION_WEIGHTS.better_exec_strategy,
      contributed_at: mergedAt,
    };
  }

  if (
    !sameValue(existing.query, merged.query) ||
    !sameValue(existing.path_params, merged.path_params) ||
    !sameValue(existing.body, merged.body)
  ) {
    return {
      agent_id: agentId,
      role: "improver",
      contribution_kind: "better_params",
      weight: CONTRIBUTION_WEIGHTS.better_params,
      contributed_at: mergedAt,
    };
  }

  if (
    (existing.verification_status === "failed" || existing.verification_status === "disabled") &&
    merged.verification_status !== existing.verification_status
  ) {
    return {
      agent_id: agentId,
      role: "maintainer",
      contribution_kind: "recovery_after_drift",
      weight: CONTRIBUTION_WEIGHTS.recovery_after_drift,
      contributed_at: mergedAt,
    };
  }

  if (
    !sameValue(existing.description, merged.description) ||
    !sameValue(existing.semantic, merged.semantic) ||
    !sameValue(existing.headers_template, merged.headers_template) ||
    !sameValue(existing.dom_extraction, merged.dom_extraction) ||
    !sameValue(existing.trigger_url, merged.trigger_url)
  ) {
    return {
      agent_id: agentId,
      role: "improver",
      contribution_kind: "better_description",
      weight: CONTRIBUTION_WEIGHTS.better_description,
      contributed_at: mergedAt,
    };
  }

  return null;
}

function dedupeContributors(
  contributors: NonNullable<EndpointDescriptor["lineage"]>["contributors"]
): NonNullable<EndpointDescriptor["lineage"]>["contributors"] {
  const deduped: NonNullable<EndpointDescriptor["lineage"]>["contributors"] = [];
  const seen = new Set<string>();
  for (const contributor of contributors) {
    const key = [
      contributor.agent_id,
      contributor.role,
      contributor.contribution_kind,
      contributor.evidence_ref ?? "",
    ].join("|");
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(contributor);
  }
  return deduped;
}

function computeCanonicalFingerprint(endpoint: EndpointDescriptor): string {
  return [
    endpoint.method,
    normalizeTemplate(endpoint.url_template),
    stableKeyList(endpoint.query),
    stableKeyList(endpoint.path_params),
    stableKeyList(endpoint.body),
    endpoint.semantic?.action_kind ?? "",
    endpoint.semantic?.resource_kind ?? "",
  ].join("|");
}

function stableKeyList(value: Record<string, unknown> | Record<string, string> | undefined): string {
  return value ? Object.keys(value).sort().join(",") : "";
}

function sameValue(a: unknown, b: unknown): boolean {
  return JSON.stringify(a ?? null) === JSON.stringify(b ?? null);
}
