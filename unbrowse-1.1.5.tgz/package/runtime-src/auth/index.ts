import { BrowserManager } from "agent-browser/dist/browser.js";
import { executeCommand } from "agent-browser/dist/actions.js";
import { storeCredential, getCredential, deleteCredential } from "../vault/index.js";
import { nanoid } from "nanoid";
import { isDomainMatch, getRegistrableDomain } from "../domain.js";
import { log } from "../logger.js";
import path from "node:path";
import os from "node:os";
import fs from "node:fs";

const LOGIN_TIMEOUT_MS = Number(process.env.UNBROWSE_AUTH_LOGIN_TIMEOUT_MS || "300000");
const POLL_INTERVAL_MS = 2_000;
const MIN_WAIT_MS = 15_000; // Always wait at least 15s so user has time to log in

export function isAuthPagePath(pathname: string): boolean {
  return /\/(login|signin|sign-in|signup|sign-up|register|join|sso|auth|oauth|uas\/login|checkpoint|forgot-password|reset-password|verify|verification)(\/|$)/i.test(pathname);
}

/**
 * Returns the persistent profile directory for a given domain.
 * Stored under ~/.unbrowse/profiles/<registrableDomain>.
 * Exporting so capture/execute can also launch with the profile if needed.
 */
export function getProfilePath(domain: string): string {
  return path.join(os.homedir(), ".unbrowse", "profiles", getRegistrableDomain(domain));
}
export interface LoginResult {
  success: boolean;
  domain: string;
  cookies_stored: number;
  headers_stored?: number;
  blank_slate?: boolean;
  error?: string;
}

export async function clearStoredAuth(domain: string): Promise<void> {
  const regDomain = getRegistrableDomain(domain);
  const keys = new Set<string>([`auth:${regDomain}`]);
  if (domain !== regDomain) keys.add(`auth:${domain}`);
  for (const key of keys) {
    try {
      await deleteCredential(key);
    } catch {
      // best effort
    }
  }
}

/**
 * Open a visible browser for the user to complete login.
 * Waits up to 120s for navigation back to the target domain, then captures cookies.
 * Uses an isolated persistent profile per domain.
 */
export async function interactiveLogin(
  url: string,
  domain?: string,
  opts?: {
    blankSlate?: boolean;
  },
): Promise<LoginResult> {
  const targetDomain = domain ?? new URL(url).hostname;
  const blankSlate = !!opts?.blankSlate;
  const profileDir = getProfilePath(targetDomain);

  const browser = new BrowserManager();
  log("auth", `interactiveLogin — url: ${url}, domain: ${targetDomain}, blank_slate=${blankSlate}`);

  try {
    if (blankSlate) {
      await clearStoredAuth(targetDomain);
      try {
        fs.rmSync(profileDir, { recursive: true, force: true });
      } catch {
        // best effort
      }
    }
    fs.mkdirSync(profileDir, { recursive: true });
    await browser.launch({
      action: "launch",
      id: nanoid(),
      headless: false,
      profile: profileDir,
      userAgent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    });
    await executeCommand({ action: "navigate", id: nanoid(), url }, browser);

    const page = browser.getPage();
    const startTime = Date.now();

    // Snapshot initial cookies so we can detect new ones after login
    const context = browser.getContext();
    const initialCookies = context ? await context.cookies() : [];
    const initialCookieCount = initialCookies.filter((c) => isDomainMatch(c.domain, targetDomain)).length;
    log("auth", `initial cookies for ${targetDomain}: ${initialCookieCount}`);

    // Wait for user to complete login — detect via cookie changes + URL change
    let loggedIn = false;
    let lastLoggedUrl = "";
    while (Date.now() - startTime < LOGIN_TIMEOUT_MS) {
      await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
      const elapsed = Date.now() - startTime;

      try {
        const currentUrl = page.url();
        const currentDomain = new URL(currentUrl).hostname.toLowerCase();
        const targetNorm = targetDomain.toLowerCase();

        if (currentUrl !== lastLoggedUrl) {
          log("auth", `navigated to: ${currentUrl}`);
          lastLoggedUrl = currentUrl;
        }

        // Don't even check for login completion until MIN_WAIT_MS has passed
        if (elapsed < MIN_WAIT_MS) continue;

        const isOnTarget = currentDomain === targetNorm || currentDomain.endsWith("." + targetNorm);
        if (isOnTarget) {
          const isStillLogin = isAuthPagePath(new URL(currentUrl).pathname);

          // Check if new cookies appeared (the real signal that login happened)
          const currentCookies = context ? await context.cookies() : [];
          const currentCookieCount = currentCookies.filter((c) => isDomainMatch(c.domain, targetDomain)).length;
          const gotNewCookies = currentCookieCount > initialCookieCount;

          if (!isStillLogin && gotNewCookies) {
            loggedIn = true;
            log("auth", `login complete — ${currentUrl} (cookies: ${initialCookieCount} → ${currentCookieCount})`);
            break;
          }

          // Handle "already logged in" — user was redirected away from login
          // to a non-login page, and cookies already exist (even if count didn't change).
          // This means the persistent profile already has the session.
          if (!isStillLogin && currentCookieCount > 0) {
            loggedIn = true;
            log("auth", `already logged in — ${currentUrl} (${currentCookieCount} cookies present)`);
            break;
          }
        }
      } catch { /* page navigating */ }
    }

    const finalContext = browser.getContext();
    const cookies = finalContext ? await finalContext.cookies() : [];
    const domainCookies = cookies.filter((c) => isDomainMatch(c.domain, targetDomain));
    const authHeaders = await extractStorageAuthHeaders(page);
    const finalUrl = (() => {
      try {
        return page.url();
      } catch {
        return url;
      }
    })();
    const finalPathname = (() => {
      try {
        return new URL(finalUrl).pathname;
      } catch {
        return "/";
      }
    })();

    if (!loggedIn) {
      log("auth", `login not confirmed after ${Math.round((Date.now() - startTime) / 1000)}s — final_url=${finalUrl}`);
      return {
        success: false,
        domain: targetDomain,
        cookies_stored: domainCookies.length,
        headers_stored: Object.keys(authHeaders).length,
        blank_slate: blankSlate,
        error: isAuthPagePath(finalPathname)
          ? `Still on auth page: ${finalPathname}`
          : "Login was not confirmed",
      };
    }

    if (domainCookies.length === 0 && Object.keys(authHeaders).length === 0) {
      return {
        success: false,
        domain: targetDomain,
        cookies_stored: 0,
        headers_stored: 0,
        blank_slate: blankSlate,
        error: "No cookies or auth headers captured for domain",
      };
    }

    const storableCookies = domainCookies.map((c) => ({
      name: c.name, value: c.value, domain: c.domain, path: c.path,
      secure: c.secure, httpOnly: c.httpOnly, sameSite: c.sameSite, expires: c.expires,
    }));

    const vaultKey = `auth:${getRegistrableDomain(targetDomain)}`;
    await storeCredential(vaultKey, JSON.stringify({ cookies: storableCookies, headers: authHeaders }));
    log("auth", `stored ${storableCookies.length} cookies and ${Object.keys(authHeaders).length} auth headers under ${vaultKey}`);

    return {
      success: true,
      domain: targetDomain,
      cookies_stored: storableCookies.length,
      headers_stored: Object.keys(authHeaders).length,
      blank_slate: blankSlate,
    };
  } finally {
    try {
      const context = browser.getContext();
      if (context) await Promise.race([context.close(), new Promise<void>((r) => setTimeout(r, 4000))]);
    } catch { /* ignore */ }
  }
}

/**
 * Extract cookies directly from Chrome/Firefox SQLite databases.
 * No browser launch needed, Chrome can stay open.
 * Stores extracted cookies in the vault for subsequent use.
 * Always stores under the registrable domain key for consistency.
 */
export async function extractBrowserAuth(
  domain: string,
  opts?: {
    browser?: "auto" | "firefox" | "chrome" | "chromium";
    chromeProfile?: string;
    firefoxProfile?: string;
    chromium?: {
      profile?: string;
      userDataDir?: string;
      cookieDbPath?: string;
      safeStorageService?: string;
      browserName?: string;
    };
  }
): Promise<LoginResult> {
  const { extractBrowserCookies } = await import("./browser-cookies.js");

  const result = extractBrowserCookies(domain, opts);

  if (result.cookies.length === 0) {
    return {
      success: false,
      domain,
      cookies_stored: 0,
      error: result.warnings.join("; ") || "No cookies found in any browser",
    };
  }

  // Store in vault under same format as interactiveLogin
  const storableCookies = result.cookies.map((c) => ({
    name: c.name,
    value: c.value,
    domain: c.domain,
    path: c.path,
    secure: c.secure,
    httpOnly: c.httpOnly,
    sameSite: c.sameSite,
    expires: c.expires,
  }));

  // Normalize: always store under registrable domain for consistent lookups
  const vaultKey = `auth:${getRegistrableDomain(domain)}`;
  await storeCredential(
    vaultKey,
    JSON.stringify({ cookies: storableCookies })
  );

  log("auth", `stored ${storableCookies.length} cookies for ${domain} (key: ${vaultKey}) from ${result.source}`);
  return { success: true, domain, cookies_stored: storableCookies.length };
}

type AuthCookie = {
  name: string;
  value: string;
  domain: string;
  path?: string;
  secure?: boolean;
  httpOnly?: boolean;
  sameSite?: string;
  expires?: number;
};

export type AuthMaterial = {
  cookies: AuthCookie[];
  headers: Record<string, string>;
};

export async function extractStorageAuthHeaders(page: {
  evaluate: <T>(fn: () => T | Promise<T>) => Promise<T>;
}): Promise<Record<string, string>> {
  try {
    const storage = await page.evaluate(() => {
      const snapshot = (store: Storage) =>
        Object.fromEntries(Array.from({ length: store.length }, (_, i) => {
          const key = store.key(i) ?? "";
          return [key, store.getItem(key) ?? ""];
        }).filter(([key]) => key));
      return {
        local: snapshot(window.localStorage),
        session: snapshot(window.sessionStorage),
      };
    });
    const entries = { ...(storage?.local ?? {}), ...(storage?.session ?? {}) } as Record<string, string>;
    const tokenEntry = Object.entries(entries).find(([key, value]) =>
      typeof value === "string" &&
      value.trim().length > 0 &&
      (/^(jwtToken|token|authToken|accessToken|access_token)$/i.test(key) || /^eyJ[A-Za-z0-9_-]+\./.test(value)),
    );
    if (!tokenEntry) return {};
    const [key, value] = tokenEntry;
    const normalized = value.trim();
    const headerValue = /jwt/i.test(key) ? `Token ${normalized}` : /^Bearer\s+/i.test(normalized) ? normalized : `Bearer ${normalized}`;
    return { Authorization: headerValue };
  } catch {
    return {};
  }
}

/** Filter out expired cookies. Session cookies (expires <= 0) are kept. */
function filterExpired(cookies: AuthCookie[]): AuthCookie[] {
  const now = Math.floor(Date.now() / 1000);
  return cookies.filter((c) => {
    if (c.expires == null || c.expires <= 0) return true; // session cookie
    return c.expires > now;
  });
}

/**
 * Retrieve stored auth cookies for a domain from the vault.
 * Filters out expired cookies automatically.
 * Checks both registrable domain key and exact domain key for backward compat.
 */
export async function getStoredAuth(
  domain: string
): Promise<AuthCookie[] | null> {
  const material = await getStoredAuthMaterial(domain);
  return material && material.cookies.length > 0 ? material.cookies : null;
}

export async function getStoredAuthMaterial(
  domain: string
): Promise<AuthMaterial | null> {
  // Try registrable domain key first (new normalized format), then exact domain
  const regDomain = getRegistrableDomain(domain);
  const keysToTry = [`auth:${regDomain}`];
  if (domain !== regDomain) keysToTry.push(`auth:${domain}`);

  for (const key of keysToTry) {
    const stored = await getCredential(key);
    if (!stored) continue;
    try {
      const parsed = JSON.parse(stored) as { cookies?: AuthCookie[]; headers?: Record<string, string> };
      const cookies = parsed.cookies ?? [];
      const headers = parsed.headers ?? {};

      const valid = filterExpired(cookies);
      if (valid.length === 0 && Object.keys(headers).length === 0) {
        log("auth", `all ${cookies.length} cookies for ${domain} (key: ${key}) are expired — deleting`);
        await deleteCredential(key);
        continue;
      }
      if (valid.length < cookies.length) {
        log("auth", `filtered ${cookies.length - valid.length} expired cookies for ${domain}`);
      }
      return { cookies: valid, headers };
    } catch {
      continue;
    }
  }
  return null;
}

/**
 * Bird-style unified cookie resolution with auto-extract fallback.
 *
 * Fallback chain:
 *   1. Vault cookies (fast path)
 *   2. Auto-extract from Chrome/Firefox SQLite (bird pattern — always fresh)
 *
 * This ensures cookies are available without requiring the user to manually
 * call /v1/auth/steal first.
 */
export async function getAuthCookies(
  domain: string,
  opts?: {
    autoExtract?: boolean;
  },
): Promise<AuthCookie[] | null> {
  // 1. Try vault (fast)
  const vaultCookies = await getStoredAuth(domain);
  if (vaultCookies && vaultCookies.length > 0) return vaultCookies;
  if (!opts?.autoExtract) return null;

  // 2. Auto-extract from browser (bird pattern)
  log("auth", `no vault cookies for ${domain} — auto-extracting from browser`);
  try {
    const result = await extractBrowserAuth(domain);
    if (result.success && result.cookies_stored > 0) {
      return getStoredAuth(domain);
    }
  } catch (err) {
    log("auth", `browser auto-extract failed for ${domain}: ${err instanceof Error ? err.message : err}`);
  }

  return null;
}

export async function getAuthMaterial(
  domain: string,
  opts?: {
    autoExtract?: boolean;
  },
): Promise<AuthMaterial | null> {
  const stored = await getStoredAuthMaterial(domain);
  if (stored && (stored.cookies.length > 0 || Object.keys(stored.headers).length > 0)) return stored;
  if (!opts?.autoExtract) return null;
  log("auth", `no stored auth material for ${domain} — auto-extracting cookies from browser`);
  try {
    const result = await extractBrowserAuth(domain);
    if (result.success && result.cookies_stored > 0) {
      return await getStoredAuthMaterial(domain);
    }
  } catch (err) {
    log("auth", `browser auto-extract failed for ${domain}: ${err instanceof Error ? err.message : err}`);
  }
  return null;
}

/**
 * Refresh credentials from browser after a 401/403.
 * Returns true if fresh cookies were stored.
 */
export async function refreshAuthFromBrowser(domain: string): Promise<boolean> {
  log("auth", `401/403 received — attempting to refresh auth for ${domain} from browser`);
  try {
    const result = await extractBrowserAuth(domain);
    if (result.success && result.cookies_stored > 0) {
      log("auth", `refreshed ${result.cookies_stored} cookies for ${domain} from browser`);
      return true;
    }
  } catch (err) {
    log("auth", `browser refresh failed for ${domain}: ${err instanceof Error ? err.message : err}`);
  }
  return false;
}
