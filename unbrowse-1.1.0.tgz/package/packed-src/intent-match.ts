function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function getPath(obj: unknown, path: string): unknown {
  if (!isRecord(obj)) return undefined;
  let cur: unknown = obj;
  for (const key of path.split(".")) {
    if (!isRecord(cur)) return undefined;
    cur = cur[key];
  }
  return cur;
}

function hasNonEmptyString(value: unknown): boolean {
  return typeof value === "string" && value.trim().length > 0;
}

function hasAnyPath(obj: unknown, paths: string[]): boolean {
  return paths.some((path) => {
    const value = getPath(obj, path);
    return hasNonEmptyString(value) || typeof value === "number";
  });
}

function collectNestedObjects(value: unknown, visit: (obj: Record<string, unknown>) => void): void {
  if (Array.isArray(value)) {
    for (const item of value) collectNestedObjects(item, visit);
    return;
  }
  if (!isRecord(value)) return;
  visit(value);
  for (const child of Object.values(value)) collectNestedObjects(child, visit);
}

function normalizeXTweets(data: unknown): Record<string, unknown>[] {
  const rows: Record<string, unknown>[] = [];
  const seen = new Set<string>();
  collectNestedObjects(data, (obj) => {
    const result = getPath(obj, "tweet_results.result");
    if (!isRecord(result)) return;
    const restId = getPath(result, "rest_id");
    const text = getPath(result, "legacy.full_text");
    const screenName = getPath(result, "core.user_results.result.core.screen_name")
      ?? getPath(result, "core.user_results.result.legacy.screen_name");
    if (!hasNonEmptyString(restId) || !hasNonEmptyString(text) || !hasNonEmptyString(screenName)) return;
    if (seen.has(String(restId))) return;
    rows.push({
      id: String(restId),
      username: String(screenName),
      text: String(text),
      url: `https://x.com/${encodeURIComponent(String(screenName))}/status/${encodeURIComponent(String(restId))}`,
    });
    seen.add(String(restId));
  });
  return rows;
}

function normalizeXUsers(data: unknown): Record<string, unknown>[] {
  const rows: Record<string, unknown>[] = [];
  const seen = new Set<string>();
  collectNestedObjects(data, (obj) => {
    const result = getPath(obj, "user_results.result");
    const target = isRecord(result) ? result : obj;
    const screenName = getPath(target, "core.screen_name") ?? getPath(target, "legacy.screen_name");
    const name = getPath(target, "core.name") ?? getPath(target, "legacy.name");
    const description = getPath(target, "legacy.description");
    const followers = getPath(target, "legacy.followers_count");
    if (!hasNonEmptyString(screenName) || !hasNonEmptyString(name)) return;
    if (seen.has(String(screenName))) return;
    rows.push({
      username: String(screenName),
      public_identifier: String(screenName),
      name: String(name),
      ...(hasNonEmptyString(description) ? { description: String(description) } : {}),
      ...(typeof followers === "number" ? { followers_count: followers } : {}),
      url: `https://x.com/${encodeURIComponent(String(screenName))}`,
    });
    seen.add(String(screenName));
  });
  return rows;
}

function unwrapCarrier(data: unknown): unknown {
  if (!isRecord(data)) return data;
  if ("data" in data && ("_extraction" in data || Array.isArray(data.data) || isRecord(data.data))) {
    return unwrapCarrier(data.data);
  }
  return data;
}

export function projectIntentData(data: unknown, intent?: string): unknown {
  const unwrapped = unwrapCarrier(data);
  if (!intent || !isRecord(unwrapped)) return unwrapped;
  const lower = intent.toLowerCase();

  if (/\b(post|posts|tweet|tweets|status|statuses)\b/.test(lower)) {
    if (Array.isArray(unwrapped.statuses)) return unwrapped.statuses;
    if (Array.isArray(unwrapped.posts)) return unwrapped.posts;
    if (Array.isArray(unwrapped.tweets)) return unwrapped.tweets;
    const normalizedXTweets = normalizeXTweets(unwrapped);
    if (normalizedXTweets.length > 0) return normalizedXTweets;
  }

  if (/\b(person|people|user|users|profile|profiles|member|members)\b/.test(lower)) {
    if (Array.isArray(unwrapped.people)) return unwrapped.people;
    if (Array.isArray(unwrapped.users)) return unwrapped.users;
    if (Array.isArray(unwrapped.accounts)) return unwrapped.accounts;
    if (Array.isArray(unwrapped.elements)) return unwrapped.elements;
    if (Array.isArray(unwrapped.included)) return unwrapped.included;
    const normalizedXUsers = normalizeXUsers(unwrapped);
    if (normalizedXUsers.length > 0) return normalizedXUsers;
  }

  if (/\b(topic|topics|trend|trending|hashtag|hashtags)\b/.test(lower)) {
    const storyItems = getPath(unwrapped, "story_topic.stories.items");
    if (Array.isArray(storyItems)) {
      const normalized = storyItems
        .map((item) => {
          const core = getPath(item, "trend_results.result.core");
          const name = getPath(core, "name");
          const restId = getPath(item, "trend_results.result.rest_id");
          if (!hasNonEmptyString(name)) return null;
          return {
            name,
            ...(hasNonEmptyString(getPath(core, "category")) ? { category: getPath(core, "category") } : {}),
            ...(hasNonEmptyString(getPath(item, "trend_results.result.post_count")) ? { post_count: getPath(item, "trend_results.result.post_count") } : {}),
            ...(hasNonEmptyString(restId)
              ? { url: `https://x.com/search?q=${encodeURIComponent(String(name))}&src=trend_click&trend_id=${encodeURIComponent(String(restId))}` }
              : { url: `https://x.com/search?q=${encodeURIComponent(String(name))}` }),
          };
        })
        .filter((item): item is Record<string, unknown> => !!item);
      if (normalized.length > 0) return normalized;
    }
    if (Array.isArray(unwrapped.topics)) return unwrapped.topics;
    if (Array.isArray(unwrapped.trends)) return unwrapped.trends;
    if (Array.isArray(unwrapped.hashtags)) return unwrapped.hashtags;
  }

  if (/\b(repo|repository|repositories)\b/.test(lower)) {
    if (Array.isArray(unwrapped.repositories)) return unwrapped.repositories;
    if (Array.isArray(unwrapped.items)) return unwrapped.items;
  }

  return unwrapped;
}

function classifyRows(rows: unknown[], intent: string): { verdict: "pass" | "fail" | "skip"; reason: string } {
  if (rows.length === 0) return { verdict: "fail", reason: "empty_array" };
  if (rows.every((row) => !isRecord(row))) return { verdict: "fail", reason: "primitive_rows" };

  const objects = rows.filter(isRecord);
  if (objects.length === 0) return { verdict: "fail", reason: "primitive_rows" };

  const lower = intent.toLowerCase();

  if (/\b(repo|repository|repositories)\b/.test(lower)) {
    const matching = objects.filter((row) =>
      hasAnyPath(row, ["full_name", "name", "repository.name"]) &&
      hasAnyPath(row, ["url", "description", "stargazers_count", "stars", "owner.login", "owner"])
    );
    return matching.length >= 1 ? { verdict: "pass", reason: "repository_rows" } : { verdict: "fail", reason: "wrong_entity_type" };
  }

  if (/\b(person|people|profile|profiles|member|members|user|users)\b/.test(lower)) {
    const matching = objects.filter((row) =>
      hasAnyPath(row, ["name", "title", "public_identifier", "username"]) &&
      hasAnyPath(row, ["headline", "url", "public_identifier", "username"])
    );
    const minRows = /\b(profile|profiles|user|users|person)\b/.test(lower) && !/\bsearch\b/.test(lower) ? 1 : 2;
    return matching.length >= minRows ? { verdict: "pass", reason: "people_rows" } : { verdict: "fail", reason: "wrong_entity_type" };
  }

  if (/\b(post|posts|tweet|tweets|status|statuses)\b/.test(lower)) {
    const matching = objects.filter((row) =>
      hasAnyPath(row, ["id", "url", "uri"]) &&
      hasAnyPath(row, ["content", "text", "title", "account.username", "account.acct", "username"])
    );
    return matching.length >= 1 ? { verdict: "pass", reason: "post_rows" } : { verdict: "fail", reason: "wrong_entity_type" };
  }

  if (/\b(topic|topics|trend|trending|hashtag|hashtags)\b/.test(lower)) {
    const matching = objects.filter((row) =>
      hasAnyPath(row, ["name", "title", "query"]) &&
      hasAnyPath(row, ["url", "name", "query"])
    );
    return matching.length >= 2 ? { verdict: "pass", reason: "topic_rows" } : { verdict: "fail", reason: "wrong_entity_type" };
  }

  return { verdict: "skip", reason: "unclassified_array" };
}

export function assessIntentResult(data: unknown, intent?: string): {
  verdict: "pass" | "fail" | "skip";
  reason: string;
  projected: unknown;
} {
  const projected = projectIntentData(data, intent);

  if (projected == null) return { verdict: "fail", reason: "no_data", projected };
  if (typeof projected === "string") {
    const trimmed = projected.trim().toLowerCase();
    if (!trimmed) return { verdict: "fail", reason: "empty_text", projected };
    if (trimmed.startsWith("<!doctype") || trimmed.startsWith("<html") || trimmed.startsWith("<body")) {
      return { verdict: "fail", reason: "html_payload", projected };
    }
    return { verdict: "skip", reason: "plain_text", projected };
  }

  if (Array.isArray(projected)) {
    const classified = classifyRows(projected, intent ?? "");
    return { ...classified, projected };
  }

  if (isRecord(projected)) {
    if ("error" in projected) return { verdict: "fail", reason: String(projected.error || "error_payload"), projected };
    if ("available_endpoints" in projected || "available_operations" in projected) {
      return { verdict: "fail", reason: "deferral_payload", projected };
    }
    if ("learned_skill_id" in projected && !("data" in projected)) {
      return { verdict: "fail", reason: "learned_skill_only", projected };
    }
    if ("message" in projected && !("data" in projected)) {
      return { verdict: "fail", reason: "message_only", projected };
    }
    const lower = (intent ?? "").toLowerCase();
    if (/\b(person|people|profile|profiles|member|members|user|users)\b/.test(lower)) {
      const classified = classifyRows([projected], intent ?? "");
      return { ...classified, projected };
    }
  }

  return { verdict: "skip", reason: "unclassified_payload", projected };
}
