/**
 * Auto-update orchestrator — called from cli.ts on every invocation.
 * Checks if an update is due, then spawns a detached background worker.
 * Never blocks the CLI.
 */

import { lstatSync, readFileSync, writeFileSync, mkdirSync } from "fs";
import { join } from "path";
import { spawn } from "child_process";
import { homedir } from "os";
import { getPackageRoot, isManagedSkillInstall, resolveSiblingEntrypoint, runtimeArgsForEntrypoint } from "./runtime/paths.js";

const HOME = homedir();
const CONFIG_DIR = join(HOME, ".unbrowse");
const CONFIG_PATH = join(CONFIG_DIR, "config.json");
const CHECK_INTERVAL = 4 * 60 * 60 * 1000; // 4 hours

/** Non-blocking auto-update check. Call at CLI startup — returns immediately. */
export function maybeAutoUpdate(metaUrl: string): void {
  if (process.env.UNBROWSE_DISABLE_AUTO_UPDATE === "1") return;
  if (!isManagedSkillInstall(metaUrl)) return;

  const skillDir = getPackageRoot(metaUrl);
  try {
    // Skip dev installs (symlinks to monorepo)
    if (lstatSync(skillDir).isSymbolicLink()) return;
  } catch {
    return; // skill dir doesn't exist
  }

  // Read config for last check timestamp
  let config: Record<string, unknown> = {};
  try {
    config = JSON.parse(readFileSync(CONFIG_PATH, "utf-8"));
  } catch { /* fresh install, no config yet */ }

  const lastCheck = (config.last_update_check as number) || 0;
  if (Date.now() - lastCheck < CHECK_INTERVAL) return;

  // Update timestamp immediately to prevent concurrent checks
  config.last_update_check = Date.now();
  try {
    mkdirSync(CONFIG_DIR, { recursive: true });
    writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
  } catch { /* non-critical */ }

  // Spawn detached worker — CLI can exit without waiting
  const workerPath = resolveSiblingEntrypoint(metaUrl, "auto-update-worker");
  const child = spawn(process.execPath, runtimeArgsForEntrypoint(metaUrl, workerPath), {
    detached: true,
    stdio: "ignore",
    cwd: skillDir,
    env: { ...process.env },
  });
  child.unref();
}
